package com.robertvduursen.kotlin_app.database

data class myActivities (var id: String, var fname: String){
}