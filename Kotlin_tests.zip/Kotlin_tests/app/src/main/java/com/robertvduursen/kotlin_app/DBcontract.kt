package com.robertvduursen.kotlin_app

import android.provider.BaseColumns

object DBcontract {
    // Table contents are grouped together in an anonymous object.
    class UserEntry : BaseColumns {
        companion object {
            val TABLE_NAME = "table_one"
            val COLUMN_ID = "ID"
            val COLUMN_FNAME = "fname"
        }


    }
}